export const Input = ({ type = "text", value, onChange }) => (
  <input
    type={type}
    value={value}
    onChange={onChange}
    className="p-2 rounded border bg-gray-900 text-white w-full"
  />
);