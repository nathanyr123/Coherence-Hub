import React from 'react'
import ReactDOM from 'react-dom/client'
import CoherenceHub from './CoherenceHub'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <CoherenceHub />
  </React.StrictMode>
)